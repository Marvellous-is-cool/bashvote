const express = require("express");
const router = express.Router();
const clientController = require("../../controllers/clientController");
const adminController = require("../../controllers/adminController");
const voteNowRouter = require("./voteNow.js");
const authMiddleware = require("../../middlewares/authMiddleware");
const adminContestantRouter = require("../adminRoutes/adminContestantRoute"); // Import the adminContestantRoute
const configModel = require("../../models/config");
const asyncHandler = require("../../middlewares/asyncHandler");
const { voteLimiter } = require("../../middlewares/rateLimiter");
const validate = require("../../middlewares/validate");
const adminService = require("../../services/adminService");
const { adminLoginSchema } = require("../../validators/authValidator");

// // // Index route
router.get(
  "/",
  asyncHandler(async (req, res) => {
    const awards = await clientController.getAwards();
    res.render("index", { awards });
  }),
);

router.get("/", async (req, res) => {
  try {
    res.render("bye");
  } catch (error) {
    console.error("Error rendering index:", error);
    res.status(500).send("Internal Server Error");
    res.render("bye");
  }
});

// router.post(
//   "/vote",
//   voteLimiter,
//   asyncHandler(async (req, res) => {
//     const { award } = req.body;

//     // Fetch selected award details
//     const selectedAward = await clientController.getSelectedAward(award);

//     // Fetch contestants for the selected award
//     const contestants = await clientController.getContestantsForAward(award);

//     res.render("contestants", {
//       selectedAward,
//       contestants,
//     });
//   })
// );

// router.get(
//   "/contestant/:id/votenow/payment",
//   asyncHandler(async (req, res) => {
//     const contestantId = req.params.id;

//     // Fetch contestant details by ID with associated award title
//     const selectedContestant = await clientController.getContestantById(
//       contestantId
//     );

//     // Pass both selectedContestant and awardTitle to the template
//     res.render("voteNow", {
//       selectedContestant,
//       awardTitle: selectedContestant.award_titles[0], // Assuming there's only one award title
//     });
//   })
// );

// router.use("/", voteNowRouter);

// // // Define the route for /voteNowSucess
// router.get(
//   "/voteNowSucess",
//   asyncHandler(async (req, res) => {
//     const { status, email, contestantId } = req.query;

//     // Fetch contestant details by ID using the correct function
//     const selectedContestant = await clientController.getContestantById(
//       parseInt(contestantId)
//     );

//     res.render("voteNowSucess", {
//       status,
//       email,
//       contestantId,
//       selectedContestant,
//     });
//   })
// );

// // Apply authMiddleware only to the routes under /admin
router.use("/admin", authMiddleware, adminContestantRouter);

// Admin login route accessible without /admin prefix
router.get("/login", (req, res) => {
  const error = req.flash("error")[0]; // Get the first error message
  res.render("admin-login", { error });
});

// // Admin authentication route
router.post(
  "/authenticate",
  validate(adminLoginSchema),
  asyncHandler(async (req, res) => {
    const { username, password } = req.body;

    try {
      const { success, error, admin } = await adminService.authenticateAdmin(
        username,
        password,
      );

      if (success) {
        // Authentication successful
        req.session.regenerate((err) => {
          if (err) {
            console.error("Error regenerating session:", err);
            res.status(500).send("Internal Server Error");
          } else {
            req.session.admin = true;
            req.session.adminUsername = admin.username; // Include admin's username

            // Set session expiration to 20 hours from now
            const sessionExpiration = 20 * 60 * 60 * 1000; // 20 hours in milliseconds
            req.session.cookie.expires = new Date(
              Date.now() + sessionExpiration,
            );
            req.session.cookie.maxAge = sessionExpiration;

            res.redirect("/admin/dashboard");
          }
        });
      } else {
        // Authentication failed
        req.flash(
          "error",
          error || "Incorrect username or password. Please try again.",
        );

        res.redirect("/login");
      }
    } catch (error) {
      console.error("Error during admin authentication:", error);
      res.status(500).send("Internal Server Error");
    }
  }),
);

// Logout route
router.get("/logout", (req, res) => {
  // Destroy the session
  req.session.destroy((err) => {
    if (err) {
      console.error("Error destroying session:", err);
      res.status(500).send("Internal Server Error");
    } else {
      // Redirect to the login page after destroying the session
      res.redirect("/");
    }
  });
});
// // Endpoint to handle session destruction when the tab or connection is closed
router.post("/destroy-session", (req, res) => {
  // Destroy the session
  req.session.destroy((err) => {
    if (err) {
      console.error("Error destroying session:", err);
      res.status(500).send("Internal Server Error");
    } else {
      res.sendStatus(200);
    }
  });
});

// Live votes page
router.get(
  "/live",
  asyncHandler(async (req, res) => {
    const liveEnabled =
      (await configModel.getConfig("live_enabled")) === "true";
    if (!liveEnabled) {
      return res.status(403).render("suspended", {
        message: "Live votes are currently disabled by the admin.",
      });
    }
    // Fetch all awards and their contestants
    const awardsWithContestants =
      await clientController.getAwardsWithContestants();
    res.render("live", { awardsWithContestants });
  }),
);

// router.get("/live/votes", async (req, res) => {
//   try {
//     // Fetch admin dashboard data using the admin controller
//     const awards = await adminController.getDashboardData();
//     res.render("votes", { awards });
//   } catch (error) {
//     console.error("Error fetching admin dashboard data:", error);
//     res.status(500).send("Internal Server Error");
//   }
// });

// router.get("/live/votes", async (req, res) => {
//   try {
//     res.render("suspended");
//   } catch (error) {
//     console.error("Error rendering index:", error);
//     res.status(500).send("Internal Server Error");
//   }
// });

module.exports = router;
