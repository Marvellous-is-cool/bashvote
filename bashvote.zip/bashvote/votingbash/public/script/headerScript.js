// headerScript.js

function toggleMenu() {
  const menuOverlay = document.getElementById("menuOverlay");
  menuOverlay.style.display =
    menuOverlay.style.display === "none" ? "flex" : "none";
}
